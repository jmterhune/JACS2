﻿let courtExtendControllerInstance = null;
class CourtExtendController {
    constructor(params = {}) {
        this.moduleId = params.moduleId;
        this.userId = params.userId;
        this.isAdmin = params.isAdmin;
        this.adminRole = params.adminRole;
        this.service = params.service;
        this.courtId = params.courtId;
        this.cancelUrl = params.cancelUrl;
        courtExtendControllerInstance = this;
    }
    init() {
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        // Initialize datepicker
        $('#txtStartDate').datepicker({
            autoclose: true,
            format: 'mm/dd/yyyy'
        });

        // Handle cancel button
        $('#btnCancel').click(function (e) {
            e.preventDefault();
            window.location.href = this.cancelUrl;
        });

        // Form submission
        $('#btnExtend').click(function (e) {
            e.preventDefault();
            $('#btnExtend').prop('disabled', true).find('i').removeClass('fas fa-save').addClass('fas fa-spinner fa-spin');
            courtExtendControllerInstance.submitExtendForm();

        });

    }

    submitExtendForm() {

        var startTemplate = $('#ddlStartTemplate').val();
        var weeks = $('#txtWeeks').val();
        var startDate = $('#txtStartDate').val();
        var courtId = $('#hfCourtId').val();

        if (!startTemplate || !weeks || !startDate) {
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                text: 'All fields are required.'
            });
            return false;
        }

        if (weeks <= 0) {
            Swal.fire({
                icon: 'error',
                title: 'Validation Error',
                text: 'Weeks to extend must be greater than 0.'
            });
            return false;
        }

        const getUrl = `${this.service.baseUrl}CourtTemplateAPI/AutoExtend`;
        var formData = {
            CourtId: parseInt($('#hdCourtId').val()),
            StartTemplateId: parseInt($('#ddlStartTemplate').val()),
            Weeks: parseInt($('#txtWeeks').val()),
            StartDate: $('#txtStartDate').val()
        };

        $.ajax({
            url: getUrl,
            type: 'POST',
            data: JSON.stringify(formData),
            contentType: 'application/json',
            beforeSend: xhr => this.setAjaxHeaders(xhr),
            success: response => {
                if (response.success) {
                    Swal.fire('Success', response.message, 'success');
                    window.location.href = this.cancelUrl;
                } else {
                    Swal.fire('Error', 'Extension failed', 'error');
                }
                $('#btnExtend').prop('disabled', false).find('i').removeClass('fas fa-spinner fa-spin').addClass('fas save');
            },
            error: () => {
                Swal.fire('Error', 'An error occurred', 'error');
                $('#btnExtend').prop('disabled', false).find('i').removeClass('fas fa-spinner fa-spin').addClass('fas save');
            }
        });
        return false; // Prevent default form submission
    }
    setAjaxHeaders(xhr) {
        xhr.setRequestHeader('ModuleId', this.moduleId);
        xhr.setRequestHeader('TabId', this.service.framework.getTabId());
        xhr.setRequestHeader('RequestVerificationToken', this.service.framework.getAntiForgeryValue());
    }

}