﻿let attorneyControllerInstance = null;
class AttorneyController {
    constructor(params = {}) {
        // Default values with parameter overrides
        this.moduleId = params.moduleId || -1;
        this.userId = params.userId || -1;
        this.isAdmin = params.isAdmin || false;
        this.adminRole = params.adminRole || 'Admin';
        this.attorneyId = -1;
        this.service = params.service || null;
        this.deleteUrl = null;
        attorneyControllerInstance = this;
    }
    init() {
        const isAdmin = this.isAdmin;
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        this.deleteUrl = `${this.service.baseUrl}AttorneyAPI/DeleteAttorney/`;
        this.attorneyId = Number(this.getValueFromUrl('aid'));
        if (this.attorneyId > 0) {
            this.ViewAttorney(this.attorneyId);
        } else {
            $("#headerText").html("Create New Attorney");
        }
        $("#cmdDelete").on("click", function (e) {
            e.preventDefault();
            var attorneyId = $("#hdAttorneyId").val();
            $.dnnConfirm({
                text: 'Are you sure you wish to delete this Attorney?',
                yesText: 'Yes',
                noText: 'No',
                title: 'Delete Attorney?',
                callbackTrue: function () {
                    attorneyControllerInstance.DeleteAttorney(attorneyId);
                }
            });
        });
        $("input[name='enabled']").on("change", function () {
            $("#radio-error").hide();
            $("input[name='enabled']").removeClass("is-invalid");
        });
        $("#cmdSave").on("click", function (e) {
            e.preventDefault();
            let isValid = true;

            // Validate Account Status (radio buttons)
            const isRadioSelected = $("input[name='enabled']:checked").length > 0;
            const $radioError = $("#radio-error");
            const $radioInputs = $("input[name='enabled']");
            if (!isRadioSelected) {
                $radioError.show();
                $radioInputs.addClass("is-invalid");
                isValid = false;
            } else {
                $radioError.hide();
                $radioInputs.removeClass("is-invalid");
            }

            // Validate Name
            const $attyName = $("#attyName");
            const $attyNameError = $attyName.next(".invalid-feedback");
            if ($attyName.val().trim() === "") {
                $attyNameError.show();
                $attyName.addClass("is-invalid");
                isValid = false;
            } else {
                $attyNameError.hide();
                $attyName.removeClass("is-invalid");
            }

            // Validate Bar Number
            const $attyBar = $("#attyBar");
            const $attyBarError = $attyBar.next(".invalid-feedback");
            if ($attyBar.val().trim() === "") {
                $attyBarError.show();
                $attyBar.addClass("is-invalid");
                isValid = false;
            } else {
                $attyBarError.hide();
                $attyBar.removeClass("is-invalid");
            }

            // Validate Email Addresses
            const $hdEmails = $("#hdEmails");
            const $emailError = $("#email-error");
            const $emailList = $("#email-list");
            // Assuming #hdEmails contains a string of emails or #email-list has <li> elements
            const hasEmails = $hdEmails.val().trim() !== "" || $emailList.children().length > 0;
            if (!hasEmails) {
                $emailError.show();
                $emailList.addClass("is-invalid");
                isValid = false;
            } else {
                $emailError.hide();
                $emailList.removeClass("is-invalid");
            }
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const emails = $hdEmails.val().split(",").filter(e => e.trim() !== "");
            const allEmailsValid = emails.every(email => emailRegex.test(email));
            if (!allEmailsValid) {
                $emailError.text("All email addresses must be valid.");
                $emailError.show();
                $emailList.addClass("is-invalid");
                isValid = false;
            }

            // Proceed with save if all validations pass
            if (isValid) {
                attorneyControllerInstance.SaveAttorney();
            }
        });
        // Clear validation errors on input/change
        $("input[name='enabled']").on("change", function () {
            $("#radio-error").hide();
            $("input[name='enabled']").removeClass("is-invalid");
        });

        $("#attyName").on("input", function () {
            const $this = $(this);
            if ($this.val().trim() !== "") {
                $this.next(".invalid-feedback").hide();
                $this.removeClass("is-invalid");
            }
        });

        $("#attyBar").on("input", function () {
            const $this = $(this);
            if ($this.val().trim() !== "") {
                $this.next(".invalid-feedback").hide();
                $this.removeClass("is-invalid");
            }
        });

        // Clear email error when a new email is added (assuming #new-email adds to #email-list or #hdEmails)
        $("#new-email").on("click", function () {
            // This assumes clicking "New Email" opens a UI to add emails, and validation clears after adding
            // Adjust based on how emails are added in your app
            setTimeout(() => {
                if ($("#hdEmails").val().trim() !== "" || $("#email-list").children().length > 0) {
                    $("#email-error").hide();
                    $("#email-list").removeClass("is-invalid");
                }
            }, 100); // Delay to allow email addition to update DOM
        });
        $("#new-email").on("click", function (e) {
            $("#email-list").append('<li><input type="text" class="form-control me-3 d-inline-block" value=""><a href="#" class="delete-email" role="button" aria-disabled="true" aria-label="Delete Email Address"><i class="fas fa-trash"></i></a></li>');
        });
        $(document).on('click', '.delete-email', function (e) {
            e.preventDefault(); // Prevent default link behavior
            $(this).closest('li').remove(); // Remove the parent <li>
        });
    }
    DeleteAttorney(attorneyId) {
        $.ajax({
            url: attorneyControllerInstance.deleteUrl + attorneyId,
            type: 'GET',
            success: function (result) {
                attorneyControllerInstance.attorneyTable.draw();
            },
            error: function (error) {
                ShowAlert("Error Deleting Attorney", error);
            }
        });
    }
    getValueFromUrl(param) {
        try {
            const urlObj = new URL(window.location.href);
            const pathSegments = urlObj.pathname.split('/');
            const paramIndex = pathSegments.indexOf(param);
            if (paramIndex !== -1 && paramIndex + 1 < pathSegments.length) {
                return pathSegments[paramIndex + 1];
            }
            return null;
        } catch (e) {
            console.error('Error Retrieving URL parameter:', e);
            return null;
        }
    }

    getQueryStringParam(key) {
        const params = new URLSearchParams(window.location.search);
        return params.get(key);
    }

    // Example usage

    ClearDetailForm() {
        $("#attyName").html("");
        $("#attyBar").html("");
        $("#attyPhone").html("");
        $("#attySchedule").html("");
        $("#attyEnabled").html("");
        $("#attyNotes").html("");
        $("#hdAttorneyId").val("");
        $("#attyEmails").html("");
    }
    ClearEditForm() {
        $("#attyName").val("");
        $("#attyBar").val("");
        $("#attyPhone").val("");
        $("#attyNotes").val("");
        $("#hdAttorneyId").val("");
        $("#hdScheduling").val("");
        $("#email-list").html("");
        $("#hdEmails").val("");
        $('input[name="enabled"]').prop('checked', false);
    }
    ViewAttorney(attorneyId) {
        var getUrl = `${attorneyControllerInstance.service.baseUrl}AttorneyAPI/GetAttorney/${attorneyId}`;
        try {
            $("#progress-attorney").show();
            $.ajax({
                url: getUrl,
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if (response.data) {
                        $("#attyName").val(response.data.name);
                        $("#attyBar").val(response.data.bar_num);
                        $("#attyPhone").val(response.data.phone);
                        if (response.data.enabled === true) {
                            $("#radio_enabled").prop('checked', true);
                            $("#radio_disabled").prop('checked', false);
                        }
                        else {
                            $("#radio_disabled").prop('checked', true);
                            $("#radio_enabled").prop('checked', false);
                        }
                        $("#attyNotes").val(response.data.notes);
                        $("#hdAttorneyId").val(response.data.id);
                        $("#hdScheduling").val(response.data.scheduling);
                        if (response.data.email_list.length > 0) {
                            $("#email-list").html(response.data.email_list.map(email => `<li><input type="text" class="form-control me-3 d-inline-block" value="${email}"><a href="#" role="button" class="delete-email" aria-disabled="true" aria-label="Delete Email Address"><i class="fas fa-trash"></i></a></li>`));
                        }
                        $("#headerText").html(`Edit Attorney: ${response.data.name}`);
                        $("#progress-attorney").hide();
                    } else {
                        ShowAlert("Error", "Failed to retrieve attorney details. Please try again later.");
                    }
                },
                error: function () {
                    console.error('Failed to fetch options');
                    $("#progress-attorney").hide();
                    ShowAlert("Error", "Failed to retrieve attorney details. Please try again later.");
                }
            });

        } catch (e) {
            $("#progress-attorney").hide();
            ShowAlert("Error", "Failed to retrieve attorney details. Please try again later.");
        }
    }
    SaveAttorney() {
        if ($("#hdAttorneyId").val() === "") {
            this.CreateAttorney();
        } else {
            this.UpdateAttorney();
        }
    }
    CreateAttorney() {
        try {
            $("#progress-attorney").show();
            const attorneyData = {
                name: $("#attyName").val(),
                bar_num: $("#attyBar").val(),
                phone: $("#attyPhone").val(),
                scheduling: $("#hdScheduling").val(),
                enabled: $('input[name="enabled"]:checked').val() === "1",
                notes: $("#attyNotes").val(),
                emails: $("#email-list li input[type='text']").map(function () { return $(this).val(); }).get()
            };
            $.ajax({
                url: `${this.service.baseUrl}AttorneyAPI/CreateAttorney`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(attorneyData),
                success: function (result) {
                    if (result === 200) {
                        $("#progress-attorney").hide();
                        ShowAlert("Success", "Attorney created successfully.");
                        attorneyControllerInstance.ClearEditForm();
                    } else {
                        $("#progress-attorney").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#progress-attorney").hide();
                    ShowAlert("Error Creating Attorney", error.statusText);
                }
            });
        } catch (e) {
            ShowAlert("Error Updating Attorney", e.statusText);
            $("#progress-attorney").hide();
        }
    }
    UpdateAttorney() {
        try {
            $("#progress-attorney").show();
            const attorneyData = {
                id: $("#hdAttorneyId").val(),
                name: $("#attyName").val(),
                bar_num: $("#attyBar").val(),
                phone: $("#attyPhone").val(),
                scheduling: $("#hdScheduling").val(),
                enabled: $('input[name="enabled"]:checked').val() === "1",
                notes: $("#attyNotes").val(),
                emails: $("#email-list li input[type='text']").map(function () { return $(this).val(); }).get()
            };
            $.ajax({
                url: `${this.service.baseUrl}AttorneyAPI/UpdateAttorney`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(attorneyData),
                success: function (result) {
                    if (result === 200) {
                        $("#progress-attorney").hide();
                        ShowAlert("Success", "Attorney updated successfully.");
                    } else {
                        $("#progress-attorney").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#progress-attorney").hide();
                    ShowAlert("Error Updating Attorney", error.statusText);
                }
            });
        } catch (e) {
            ShowAlert("Error Updating Attorney", e.statusText);
            $("#progress-attorney").hide();
        }
    }
}