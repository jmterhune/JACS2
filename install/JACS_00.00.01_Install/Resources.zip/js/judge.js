﻿let judgeControllerInstance = null;

class JudgeController {
    constructor(params = {}) {
        this.moduleId = params.moduleId || -1;
        this.userId = params.userId || -1;
        this.isAdmin = params.isAdmin || false;
        this.adminRole = params.adminRole || 'Admin';
        this.pageSize = params.pageSize || 25;
        this.sortDirection = params.sortDirection || 'asc';
        this.recordCount = params.recordCount || 0;
        this.sortColumnIndex = params.sortColumnIndex || 2;
        this.currentPage = params.currentPage || 0;
        this.judgeId = -1;
        this.searchTerm = "";
        this.judgeTable = null;
        this.service = params.service || null;
        this.deleteUrl = null;
        judgeControllerInstance = this;
    }

    init() {
        const isAdmin = this.isAdmin;
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        this.deleteUrl = `${this.service.baseUrl}JudgeAPI/DeleteJudge/`;

        const listUrl = `${this.service.baseUrl}JudgeAPI/GetJudges/${this.recordCount}`;
        const detailModalElement = document.getElementById('JudgeDetailModal');
        if (detailModalElement) {
            detailModalElement.addEventListener('hidden.bs.modal', this.onModalClose);
        }

        const editModalElement = document.getElementById('JudgeEditModal');
        if (editModalElement) {
            editModalElement.addEventListener('hidden.bs.modal', this.onModalClose);
        }
        $(editModalElement).on('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) {
                e.preventDefault();
                $("#edit_cmdSave").trigger('click');
            }
        });

        this.populateCourts();

        this.judgeTable = $('#tblJudge').DataTable({
            searching: true,
            autoWidth: true,
            stateSave: true,
            ajax: {
                url: listUrl,
                type: "GET",
                datatype: 'json',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                data(data) {
                    data.searchText = data.search.value;
                    delete data.columns;
                },
                error: function (error) {
                    $("#tblJudge_processing").hide();
                    if (error.status === 401) {
                        ShowAlert("Error Retrieving Judges", "Please make sure you are logged in and try again. Error: " + error.statusText);
                    } else {
                        ShowAlert("Error Retrieving Judges", "The following error occurred attempting to retrieve judge information. Error: " + error.statusText);
                    }
                }
            },
            columns: [
                {
                    data: "id",
                    render: function (data) {
                        return `<button type="button" title="View Details" data-toggle="tooltip" data-id="${data}" class="judge-detail btn-command"><i class="fas fa-eye"></i></button>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "id",
                    render: function (data) {
                        return `<button type="button" title="Edit Judge" data-toggle="tooltip" data-id="${data}" class="judge-edit btn-command"><i class="fas fa-pencil"></i></button>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "name",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "phone",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "court_name",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "title",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "id",
                    render: function (data, type, row) {
                        if (isAdmin === "True") {
                            return `<button type="button" class="delete btn-command" data-toggle="tooltip" aria-role="button" title="Delete Judge" data-id="${row.id}"><i class="fas fa-trash"></i></button>`;
                        }
                        return '';
                    },
                    className: "command-item",
                    orderable: false
                },
            ],
            language: {
                emptyTable: "No Records Available.",
                zeroRecords: "No records match the search criteria you entered."
            },
            order: [[this.sortColumnIndex, this.sortDirection]],
            serverSide: true,
            processing: true,
            lengthMenu: [[25, 50, 100], [25, 50, 100]],
            pageLength: this.pageSize,
            displayStart: this.currentPage * this.pageSize,
        });

        $(".dt-length").prepend($("#lnkAdd"));
        this.judgeTable.on('draw', function () {
            
            $(".delete").on("click", function (e) {
                e.preventDefault();
                const judgeId = $(this).data("id");
                $.dnnConfirm({
                    text: 'Are you sure you wish to delete this Judge?',
                    yesText: 'Yes',
                    noText: 'No',
                    title: 'Delete Judge?',
                    callbackTrue: function () {
                        judgeControllerInstance.DeleteJudge(judgeId);
                    }
                });
            });
        });

        $(document).on('click', '.judge-detail', function (e) {
            e.preventDefault();
            var judgeId = $(this).data("id");
            judgeControllerInstance.ViewJudge(judgeId, false);
        });

        const editModal = new bootstrap.Modal(document.getElementById('JudgeEditModal'));
        $(document).on('click', '.judge-edit, #editJudgeBtn', function (e) {
            e.preventDefault();
            var judgeId = $(this).data("id") || $("#hdJudgeId").val();
            judgeControllerInstance.judgeId = judgeId;
            if (judgeId) {
                judgeControllerInstance.ViewJudge(judgeId, true);
                $("#JudgeEditModalLabel").html(`Edit Judge`);
            } else {
                judgeControllerInstance.ClearEditForm();
                $("#JudgeEditModalLabel").html("Create New Judge");
            }
            editModal.show();
        });

        $("#lnkAdd").on('click', function (e) {
            e.preventDefault();
            judgeControllerInstance.ClearEditForm();
            $("#JudgeEditModalLabel").html("Create New Judge");
            editModal.show();
        });

        $("#cmdDelete").on("click", function (e) {
            e.preventDefault();
            var judgeId = $("#hdJudgeId").val();
            $.dnnConfirm({
                text: 'Are you sure you wish to delete this Judge?',
                yesText: 'Yes',
                noText: 'No',
                title: 'Delete Judge?',
                callbackTrue: function () {
                    judgeControllerInstance.DeleteJudge(judgeId);
                }
            });
        });

        $("#edit_cmdSave").on("click", function (e) {
            e.preventDefault();
            let isValid = true;

            const $judgeName = $("#edit_judgeName");
            const $judgeNameError = $judgeName.next(".invalid-feedback");
            if ($judgeName.val().trim() === "") {
                $judgeNameError.show();
                $judgeName.addClass("is-invalid");
                isValid = false;
            } else {
                $judgeNameError.hide();
                $judgeName.removeClass("is-invalid");
            }

            if (isValid) {
                judgeControllerInstance.SaveJudge();
            }
        });

        $("#edit_judgeName").on("input", function () {
            const $this = $(this);
            if ($this.val().trim() !== "") {
                $this.next(".invalid-feedback").hide();
                $this.removeClass("is-invalid");
            }
        });
    }

    populateCourts() {
        $.ajax({
            url: `${this.service.baseUrl}CourtAPI/GetCourts`, // Assuming a similar CourtAPI exists
            type: 'GET',
            dataType: 'json',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('ModuleId', moduleId);
                xhr.setRequestHeader('TabId', service.framework.getTabId());
                xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
            },
            success: function (response) {
                const $courtSelect = $("#edit_judgeCourt");
                $courtSelect.empty();
                $courtSelect.append('<option value="">Select Court</option>');
                if (response.data) {
                    response.data.forEach(court => {
                        $courtSelect.append(`<option value="${court.id}">${court.description}</option>`);
                    });
                }
            },
            error: function () {
                console.error('Failed to fetch courts');
            }
        });
    }

    ClearState() {
        if (this.judgeTable) {
            this.judgeTable.state.clear();
            window.location.reload();
        }
    }

    DeleteJudge(judgeId) {
        $.ajax({
            url: this.deleteUrl + judgeId,
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('ModuleId', moduleId);
                xhr.setRequestHeader('TabId', service.framework.getTabId());
                xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
            },
            success: function (result) {
                if (judgeControllerInstance.judgeTable) {
                    judgeControllerInstance.judgeTable.draw();
                }
                const editModal = bootstrap.Modal.getInstance(document.getElementById('JudgeEditModal'));
                if (editModal) {
                    editModal.hide();
                }
                const detailModal = bootstrap.Modal.getInstance(document.getElementById('JudgeDetailModal'));
                if (detailModal) {
                    detailModal.hide();
                }
            },
            error: function (error) {
                ShowAlert("Error Deleting Judge", error.statusText);
            }
        });
    }

    onModalClose(event) {
        const modalId = event.target.id;
        if (modalId === 'JudgeDetailModal') {
            judgeControllerInstance.ClearDetailForm();
        } else if (modalId === 'JudgeEditModal') {
            judgeControllerInstance.ClearEditForm();
            judgeControllerInstance.ClearEditValidations();
        }
    }

    ClearDetailForm() {
        $("#judgeName").html("");
        $("#judgePhone").html("");
        $("#judgeCourt").html("");
        $("#judgeTitle").html("");
        $("#hdJudgeId").val("");
    }

    ClearEditForm() {
        $("#edit_judgeName").val("");
        $("#edit_judgePhone").val("");
        $("#edit_judgeCourt").val("");
        $("#edit_judgeTitle").val("");
        $("#edit_hdJudgeId").val("");
    }

    ClearEditValidations() {
        $("#edit_judgeName").removeClass("is-invalid");
        $("#edit_judgeName").next(".invalid-feedback").hide();
    }

    ViewJudge(judgeId, isEditMode = false) {
        const getUrl = `${this.service.baseUrl}JudgeAPI/GetJudge/${judgeId}`;
        const progressId = isEditMode ? "#edit_progress-judge" : "#progress-judge";
        $(progressId).show();

        if (!isEditMode) {
            const modal = new bootstrap.Modal(document.getElementById('JudgeDetailModal'));
            if (!modal._element.classList.contains('show')) {
                modal.show();
            }
        }

        if (judgeId) {
            $.ajax({
                url: getUrl,
                method: 'GET',
                dataType: 'json',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (response) {
                    if (response.data) {
                        if (isEditMode) {
                            $("#edit_hdJudgeId").val(response.data.id);
                            $("#edit_judgeName").val(response.data.name);
                            $("#edit_judgePhone").val(response.data.phone);
                            $("#edit_judgeCourt").val(response.data.court_id || "");
                            $("#edit_judgeTitle").val(response.data.title);
                            $("#JudgeEditModalLabel").html(`Edit Judge: ${response.data.name}`);
                        } else {
                            $("#judgeName").html(response.data.name);
                            $("#judgePhone").html(response.data.phone);
                            $("#judgeCourt").html(response.data.court_name);
                            $("#judgeTitle").html(response.data.title);
                            $("#hdJudgeId").val(response.data.id);
                        }
                        $(progressId).hide();
                    } else {
                        ShowAlert("Error", "Failed to retrieve judge details. Please try again later.");
                        $(progressId).hide();
                    }
                },
                error: function () {
                    console.error('Failed to fetch judge details');
                    ShowAlert("Error", "Failed to retrieve judge details. Please try again later.");
                    $(progressId).hide();
                }
            });
        } else {
            $(progressId).hide();
        }
    }

    SaveJudge() {
        if ($("#edit_hdJudgeId").val() === "") {
            this.CreateJudge();
        } else {
            this.UpdateJudge();
        }
        if (judgeControllerInstance.judgeTable) {
            judgeControllerInstance.ClearEditForm();
            judgeControllerInstance.judgeTable.draw();
        }
    }

    CreateJudge() {
        try {
            $("#edit_progress-judge").show();
            const judgeData = {
                name: $("#edit_judgeName").val(),
                phone: $("#edit_judgePhone").val(),
                court_id: $("#edit_judgeCourt").val() || null,
                title: $("#edit_judgeTitle").val()
            };
            $.ajax({
                url: `${this.service.baseUrl}JudgeAPI/CreateJudge`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(judgeData),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-judge").hide();
                        ShowAlert("Success", "Judge created successfully.");
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('JudgeEditModal'));
                        if (editModal) {
                            editModal.hide();
                        }
                    } else {
                        $("#edit_progress-judge").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-judge").hide();
                    ShowAlert("Error Creating Judge", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-judge").hide();
            ShowAlert("Error Creating Judge", e.statusText);
        }
    }

    UpdateJudge() {
        try {
            $("#edit_progress-judge").show();
            const judgeData = {
                id: $("#edit_hdJudgeId").val(),
                name: $("#edit_judgeName").val(),
                phone: $("#edit_judgePhone").val(),
                court_id: $("#edit_judgeCourt").val() || null,
                title: $("#edit_judgeTitle").val()
            };
            $.ajax({
                url: `${this.service.baseUrl}JudgeAPI/UpdateJudge`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(judgeData),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-judge").hide();
                        ShowAlert("Success", "Judge updated successfully.");
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('JudgeEditModal'));
                        if (editModal) {
                            editModal.hide();
                        }
                    } else {
                        $("#edit_progress-judge").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-judge").hide();
                    ShowAlert("Error Updating Judge", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-judge").hide();
            ShowAlert("Error Updating Judge", e.statusText);
        }
    }
}