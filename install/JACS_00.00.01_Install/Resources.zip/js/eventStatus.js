﻿let eventStatusControllerInstance = null;

class EventStatusController {
    constructor(params = {}) {
        this.moduleId = params.moduleId || -1;
        this.userId = params.userId || -1;
        this.isAdmin = params.isAdmin || false;
        this.adminRole = params.adminRole || 'Admin';
        this.pageSize = params.pageSize || 25;
        this.sortDirection = params.sortDirection || 'asc';
        this.recordCount = params.recordCount || 0;
        this.sortColumnIndex = params.sortColumnIndex || 2;
        this.currentPage = params.currentPage || 0;
        this.eventStatusId = -1;
        this.searchTerm = "";
        this.eventStatusTable = null;
        this.service = params.service || null;
        this.deleteUrl = null;
        eventStatusControllerInstance = this;
    }

    init() {
        const isAdmin = this.isAdmin;
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        this.deleteUrl = `${this.service.baseUrl}EventStatusAPI/DeleteEventStatus/`;

        const listUrl = `${this.service.baseUrl}EventStatusAPI/GetEventStatuses/${this.recordCount}`;
        const detailModalElement = document.getElementById('EventStatusDetailModal');
        if (detailModalElement) {
            detailModalElement.addEventListener('hidden.bs.modal', this.onModalClose);
        }

        const editModalElement = document.getElementById('EventStatusEditModal');
        if (editModalElement) {
            editModalElement.addEventListener('hidden.bs.modal', this.onModalClose);
        }
        $(editModalElement).on('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) {
                e.preventDefault();
                $("#edit_cmdSave").trigger('click');
            }
        });
        this.eventStatusTable = $('#tblEventStatus').DataTable({
            searching: true,
            autoWidth: true,
            stateSave: true,
            ajax: {
                url: listUrl,
                type: "GET",
                datatype: 'json',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                data(data) {
                    data.searchText = data.search.value;
                    delete data.columns;
                },
                error: function (error) {
                    $("#tblEventStatus").hide();
                    if (error.status === 401) {
                        ShowAlert("Error Retrieving Event Statuses", "Please make sure you are logged in and try again. Error: " + error.statusText);
                    } else {
                        ShowAlert("Error Retrieving Event Statuses", "The following error occurred attempting to retrieve event status information. Error: " + error.statusText);
                    }
                }
            },
            columns: [
                {
                    data: "id",
                    render: function (data) {
                        return `<button type="button" title="View Details" data-toggle="tooltip" data-id="${data}" class="es-detail btn-command"><i class="fas fa-eye"></i></button>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "id",
                    render: function (data) {
                        return `<button type="button" title="Edit Event Status" data-toggle="tooltip" data-id="${data}" class="es-edit btn-command"><i class="fas fa-pencil"></i></button>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "name",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "id",
                    render: function (data, type, row) {
                        if (isAdmin === "True") {
                            return `<button type="button" class="delete btn-command" data-toggle="tooltip" aria-role="button" title="Delete Event Status" data-id="${row.id}"><i class="fas fa-trash"></i></button>`;
                        }
                        return '';
                    },
                    className: "command-item",
                    orderable: false
                },
            ],
            language: {
                emptyTable: "No Records Available.",
                zeroRecords: "No records match the search criteria you entered."
            },
            order: [[this.sortColumnIndex, this.sortDirection]],
            serverSide: true,
            processing: true,
            lengthMenu: [[25, 50, 100], [25, 50, 100]],
            pageLength: this.pageSize,
            displayStart: this.currentPage * this.pageSize,
        });

        $(".dt-length").prepend($("#lnkAdd"));
        this.eventStatusTable.on('draw', function () {
            
            $(".delete").on("click", function (e) {
                e.preventDefault();
                const eventStatusId = $(this).data("id");
                $.dnnConfirm({
                    text: 'Are you sure you wish to delete this Event Status?',
                    yesText: 'Yes',
                    noText: 'No',
                    title: 'Delete Event Status?',
                    callbackTrue: function () {
                        eventStatusControllerInstance.DeleteEventStatus(eventStatusId);
                    }
                });
            });
        });

        $(document).on('click', '.es-detail', function (e) {
            e.preventDefault();
            var eventStatusId = $(this).data("id");
            eventStatusControllerInstance.ViewEventStatus(eventStatusId, false);
        });

        const editModal = new bootstrap.Modal(document.getElementById('EventStatusEditModal'));
        $(document).on('click', '.es-edit, #editEventStatusBtn', function (e) {
            e.preventDefault();
            var eventStatusId = $(this).data("id") || $("#hdEventStatusId").val();
            eventStatusControllerInstance.eventStatusId = eventStatusId;
            if (eventStatusId) {
                eventStatusControllerInstance.ViewEventStatus(eventStatusId, true);
                $("#EventStatusEditModalLabel").html(`Edit Event Status`);
            } else {
                eventStatusControllerInstance.ClearEditForm();
                $("#EventStatusEditModalLabel").html("Create New Event Status");
            }
            editModal.show();
        });

        $("#lnkAdd").on('click', function (e) {
            e.preventDefault();
            eventStatusControllerInstance.ClearEditForm();
            $("#EventStatusEditModalLabel").html("Create New Event Status");
            editModal.show();
        });

        $("#cmdDelete").on("click", function (e) {
            e.preventDefault();
            var eventStatusId = $("#hdEventStatusId").val();
            $.dnnConfirm({
                text: 'Are you sure you wish to delete this Event Status?',
                yesText: 'Yes',
                noText: 'No',
                title: 'Delete Event Status?',
                callbackTrue: function () {
                    eventStatusControllerInstance.DeleteEventStatus(eventStatusId);
                }
            });
        });

        $("#edit_cmdSave").on("click", function (e) {
            e.preventDefault();
            let isValid = true;

            const $esName = $("#edit_esName");
            const $esNameError = $esName.next(".invalid-feedback");
            if ($esName.val().trim() === "") {
                $esNameError.show();
                $esName.addClass("is-invalid");
                isValid = false;
            } else {
                $esNameError.hide();
                $esName.removeClass("is-invalid");
            }

            if (isValid) {
                eventStatusControllerInstance.SaveEventStatus();
            }
        });

        $("#edit_esName").on("input", function () {
            const $this = $(this);
            if ($this.val().trim() !== "") {
                $this.next(".invalid-feedback").hide();
                $this.removeClass("is-invalid");
            }
        });
    }

    ClearState() {
        if (this.eventStatusTable) {
            this.eventStatusTable.state.clear();
            window.location.reload();
        }
    }

    DeleteEventStatus(eventStatusId) {
        $.ajax({
            url: this.deleteUrl + eventStatusId,
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('ModuleId', moduleId);
                xhr.setRequestHeader('TabId', service.framework.getTabId());
                xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
            },
            success: function (result) {
                if (eventStatusControllerInstance.eventStatusTable) {
                    eventStatusControllerInstance.eventStatusTable.draw();
                }
                const editModal = bootstrap.Modal.getInstance(document.getElementById('EventStatusEditModal'));
                if (editModal) {
                    editModal.hide();
                }
                const detailModal = bootstrap.Modal.getInstance(document.getElementById('EventStatusDetailModal'));
                if (detailModal) {
                    detailModal.hide();
                }
            },
            error: function (error) {
                ShowAlert("Error Deleting Event Status", error.statusText);
            }
        });
    }

    onModalClose(event) {
        const modalId = event.target.id;
        if (modalId === 'EventStatusDetailModal') {
            eventStatusControllerInstance.ClearDetailForm();
        } else if (modalId === 'EventStatusEditModal') {
            eventStatusControllerInstance.ClearEditForm();
            eventStatusControllerInstance.ClearEditValidations();
        }
    }

    ClearDetailForm() {
        $("#esName").html("");
        $("#hdEventStatusId").val("");
    }

    ClearEditForm() {
        $("#edit_esName").val("");
        $("#edit_hdEventStatusId").val("");
    }

    ClearEditValidations() {
        $("#edit_esName").removeClass("is-invalid");
        $("#edit_esName").next(".invalid-feedback").hide();
    }

    ViewEventStatus(eventStatusId, isEditMode = false) {
        const getUrl = `${this.service.baseUrl}EventStatusAPI/GetEventStatus/${eventStatusId}`;
        const progressId = isEditMode ? "#edit_progress-eventstatus" : "#progress-eventstatus";
        $(progressId).show();

        if (!isEditMode) {
            const modal = new bootstrap.Modal(document.getElementById('EventStatusDetailModal'));
            if (!modal._element.classList.contains('show')) {
                modal.show();
            }
        }

        if (eventStatusId) {
            $.ajax({
                url: getUrl,
                method: 'GET',
                dataType: 'json',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (response) {
                    if (response.data) {
                        if (isEditMode) {
                            $("#edit_hdEventStatusId").val(response.data.id);
                            $("#edit_esName").val(response.data.name);
                            $("#EventStatusEditModalLabel").html(`Edit Event Status: ${response.data.name}`);
                        } else {
                            $("#esName").html(response.data.name);
                            $("#hdEventStatusId").val(response.data.id);
                        }
                        $(progressId).hide();
                    } else {
                        ShowAlert("Error", "Failed to retrieve event status details. Please try again later.");
                        $(progressId).hide();
                    }
                },
                error: function () {
                    console.error('Failed to fetch event status details');
                    ShowAlert("Error", "Failed to retrieve event status details. Please try again later.");
                    $(progressId).hide();
                }
            });
        } else {
            $(progressId).hide();
        }
    }

    SaveEventStatus() {
        if ($("#edit_hdEventStatusId").val() === "") {
            this.CreateEventStatus();
        } else {
            this.UpdateEventStatus();
        }
        if (eventStatusControllerInstance.eventStatusTable) {
            eventStatusControllerInstance.ClearEditForm();
            eventStatusControllerInstance.eventStatusTable.draw();
        }
    }

    CreateEventStatus() {
        try {
            $("#edit_progress-eventstatus").show();
            const eventStatusData = {
                name: $("#edit_esName").val()
            };
            $.ajax({
                url: `${this.service.baseUrl}EventStatusAPI/CreateEventStatus`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(eventStatusData),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-eventstatus").hide();
                        ShowAlert("Success", "Event Status created successfully.");
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('EventStatusEditModal'));
                        if (editModal) {
                            editModal.hide();
                        }
                    } else {
                        $("#edit_progress-eventstatus").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-eventstatus").hide();
                    ShowAlert("Error Creating Event Status", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-eventstatus").hide();
            ShowAlert("Error Creating Event Status", e.statusText);
        }
    }

    UpdateEventStatus() {
        try {
            $("#edit_progress-eventstatus").show();
            const eventStatusData = {
                id: $("#edit_hdEventStatusId").val(),
                name: $("#edit_esName").val()
            };
            $.ajax({
                url: `${this.service.baseUrl}EventStatusAPI/UpdateEventStatus`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(eventStatusData),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-eventstatus").hide();
                        ShowAlert("Success", "Event Status updated successfully.");
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('EventStatusEditModal'));
                        if (editModal) {
                            editModal.hide();
                        }
                    } else {
                        $("#edit_progress-eventstatus").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-eventstatus").hide();
                    ShowAlert("Error Updating Event Status", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-eventstatus").hide();
            ShowAlert("Error Updating Event Status", e.statusText);
        }
    }
}