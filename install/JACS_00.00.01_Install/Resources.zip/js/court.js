﻿let courtControllerInstance = null;

class CourtController {
    constructor(params = {}) {
        this.moduleId = params.moduleId || -1;
        this.userId = params.userId || -1;
        this.isAdmin = params.isAdmin || false;
        this.adminRole = params.adminRole || 'Admin';
        this.pageSize = params.pageSize || 25;
        this.editUrl = params.editUrl || '/';
        this.calendarUrl = params.calendarUrl || '/';
        this.sortDirection = params.sortDirection || 'asc';
        this.recordCount = params.recordCount || 0;
        this.sortColumnIndex = params.sortColumnIndex || 2;
        this.currentPage = params.currentPage || 0;
        this.courtId = -1;
        this.searchTerm = "";
        this.courtTable = null;
        this.service = params.service || null;
        this.deleteUrl = null;
        courtControllerInstance = this;
    }

    init() {
        const isAdmin = this.isAdmin;
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        this.deleteUrl = `${this.service.baseUrl}CourtAPI/DeleteCourt/`;

        const listUrl = `${this.service.baseUrl}CourtAPI/GetCourts/${this.recordCount}`;
        const editUrl = this.editUrl;
        const calendarUrl = this.calendarUrl;
        this.courtTable = $('#tblCourt').DataTable({
            searching: true,
            autoWidth: true,
            stateSave: true,
            ajax: {
                url: listUrl,
                type: "GET",
                datatype: 'json',
                data: function (data) {
                    data.searchText = data.search?.value || '';
                    delete data.columns;
                },
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                error: function (error) {
                    $("#tblCourt_processing").hide();
                    if (error.status === 401) {
                        ShowAlert("Error Retrieving Courts", "Please make sure you are logged in and try again. Error: " + error.statusText);
                    } else {
                        ShowAlert("Error Retrieving Courts", "The following error occurred attempting to retrieve court information. Error: " + error.statusText);
                    }
                }
            },
            columns: [
                {
                    data: "id",
                    render: function (data) {
                        return `<a href="${calendarUrl}/courtId/${data}" title="View Calendar" data-toggle="tooltip" class="court-detail btn-command"><i class="fas fa-eye"></i></a>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "id",
                    render: function (data) {
                        return `<a href="${editUrl}/courtId/${data}" title="Edit Court" data-toggle="tooltip" class="court-edit btn-command"><i class="fas fa-pencil"></i></a>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "description",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "judge_name",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "county_name",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "id",
                    render: function (data, type, row) {
                        if (isAdmin === "True") {
                            return `<button type="button" class="delete btn-command" data-toggle="tooltip" aria-role="button" title="Delete Court" data-id="${row.id}"><i class="fas fa-trash"></i></button>`;
                        }
                        return '';
                    },
                    className: "command-item",
                    orderable: false
                },
            ],
            language: {
                emptyTable: "No Records Available.",
                zeroRecords: "No records match the search criteria you entered."
            },
            order: [[this.sortColumnIndex, this.sortDirection]],
            serverSide: true,
            processing: true,
            lengthMenu: [[25, 50, 100], [25, 50, 100]],
            pageLength: this.pageSize,
            displayStart: this.currentPage * this.pageSize,
        });
        $(".dt-length").prepend($("#lnkAdd"));
        this.courtTable.on('draw', function () {
            $(".delete").on("click", function (e) {
                e.preventDefault();
                const courtId = $(this).data("id");
                $.dnnConfirm({
                    text: 'Are you sure you wish to delete this Court?',
                    yesText: 'Yes',
                    noText: 'No',
                    title: 'Delete Court?',
                    callbackTrue: function () {
                        courtControllerInstance.DeleteCourt(courtId);
                    }
                });
            });
        });
    }

    initEdit() {
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        this.deleteUrl = `${this.service.baseUrl}CourtAPI/DeleteCourt/`;

        const urlParams = new URLSearchParams(window.location.search);
        const courtId = urlParams.get('courtId');

        this.populateCountyDropdown();
        this.populateAttorneyDropdown('#edit_defAttorney', 'Default Prosecuting Attorney');
        this.populateAttorneyDropdown('#edit_oppAttorney', 'Default Opposing Attorney');

        if (courtId) {
            this.ViewCourt(courtId, true);
        }

        $("#edit_cmdSave").on("click", function (e) {
            e.preventDefault();
            let isValid = true;

            const $courtDescription = $("#edit_courtDescription");
            const $courtDescriptionError = $courtDescription.next(".invalid-feedback");
            if ($courtDescription.val().trim() === "") {
                $courtDescriptionError.show();
                $courtDescription.addClass("is-invalid");
                isValid = false;
            } else {
                $courtDescriptionError.hide();
                $courtDescription.removeClass("is-invalid");
            }
            const $courtCounty = $("#edit_courtCounty");
            const $courtCountyError = $courtCounty.next(".invalid-feedback");
            if ($courtCounty.val().trim() === "") {
                $courtCountyError.show();
                $courtCounty.addClass("is-invalid");
                isValid = false;
            } else {
                $courtCountyError.hide();
                $courtCounty.removeClass("is-invalid");
            }
            if (isValid) {
                courtControllerInstance.SaveCourt();
            }
        });

        $("#edit_courtDescription").on("input", function () {
            const $this = $(this);
            if ($this.val().trim() !== "") {
                $this.next(".invalid-feedback").hide();
                $this.removeClass("is-invalid");
            }
        });
    }

    ClearState() {
        if (this.courtTable) {
            this.courtTable.state.clear();
            window.location.reload();
        }
    }

    DeleteCourt(courtId) {
        $.ajax({
            url: this.deleteUrl + courtId,
            type: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('ModuleId', moduleId);
                xhr.setRequestHeader('TabId', service.framework.getTabId());
                xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
            },
            success: function (result) {
                if (courtControllerInstance.courtTable) {
                    courtControllerInstance.courtTable.draw();
                }
                window.location.href = '/court';
            },
            error: function (error) {
                ShowAlert("Error Deleting Court", error.statusText);
            }
        });
    }

    ClearEditForm() {
        $("#edit_courtDescription").val("");
        $("#edit_courtCaseNumFormat").val("");
        $("#edit_courtCounty").val("");
        $("#edit_courtPlaintiff").val("");
        $("#edit_courtDefendant").val("");
        $("#edit_defAttorney").val("");
        $("#edit_oppAttorney").val("");
        $("#edit_emailConfirmations").val("0");
        $("#edit_calendarWeeks").val("0");
        $("#edit_autoExtensionAuto").prop("checked", true);
        $("#edit_customEmailBody").val("");
        $("#edit_timeslotHeader").val("");
        $("#edit_customHeader").val("");
        $("#edit_hdCourtId").val("");
    }

    ClearEditValidations() {
        $("#edit_courtDescription").removeClass("is-invalid");
        $("#edit_courtDescription").next(".invalid-feedback").hide();
        $("#edit_courtCounty").removeClass("is-invalid");
        $("#edit_courtCounty").next(".invalid-feedback").hide();
    }

    populateCountyDropdown() {
        $.ajax({
            url: `${this.service.baseUrl}CountyAPI/GetCounties`,
            type: 'GET',
            dataType: 'json',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('ModuleId', moduleId);
                xhr.setRequestHeader('TabId', service.framework.getTabId());
                xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
            },
            success: function (response) {
                if (response.data) {
                    const $countySelect = $("#edit_courtCounty");
                    $countySelect.empty();
                    $countySelect.append('<option value="">Select a County</option>');
                    response.data.forEach(county => {
                        $countySelect.append(`<option value="${county.id}">${county.name}</option>`);
                    });
                }
            },
            error: function (error) {
                if (error.status !== 401) {
                    console.error('Failed to fetch counties for dropdown');
                    ShowAlert("Error", "Failed to load counties. Please try again later.");
                }
            }
        });
    }

    populateAttorneyDropdown(selector, placeholder) {
        $(selector).select2({
            ajax: {
                url: `${this.service.baseUrl}AttorneyAPI/GetAttorneyDropDownItems/`,
                dataType: 'json',
                delay: 500,
                data: function (params) {
                    return {
                        q: params.term,
                        page: params.page
                    };
                },
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                processResults: function (data) {
                    return {
                        results: data.map(item => ({
                            id: item.id,
                            text: item.name
                        }))
                    };
                },
                cache: true
            },
            placeholder: placeholder,
            minimumInputLength: 2,
            allowClear: true
        });
    }

    ViewCourt(courtId, isEditMode = false) {
        const getUrl = `${this.service.baseUrl}CourtAPI/GetCourt/${courtId}`;
        const progressId = "#edit_progress-court";
        $(progressId).show();

        if (courtId) {
            $.ajax({
                url: getUrl,
                method: 'GET',
                dataType: 'json',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (response) {
                    if (response.data) {
                        if (isEditMode) {
                            $("#edit_hdCourtId").val(response.data.id);
                            $("#edit_courtDescription").val(response.data.description);
                            $("#edit_courtCaseNumFormat").val(response.data.case_num_format);
                            $("#edit_courtCounty").val(response.data.county_id);
                            $("#edit_courtPlaintiff").val(response.data.plaintiff);
                            $("#edit_courtDefendant").val(response.data.defendant);
                            $("#edit_defAttorney").val(response.data.def_attorney_id).trigger('change');
                            $("#edit_oppAttorney").val(response.data.opp_attorney_id).trigger('change');
                            $("#edit_emailConfirmations").val(response.data.email_confirmations ? "1" : "0");
                            $("#edit_calendarWeeks").val(response.data.calendar_weeks);
                            $(`#edit_autoExtension${response.data.auto_extension ? 'Auto' : 'Manual'}`).prop("checked", true);
                            $("#edit_customEmailBody").val(response.data.custom_email_body);
                            $("#edit_timeslotHeader").val(response.data.timeslot_header);
                            $("#edit_customHeader").val(response.data.custom_header);
                        }
                        $(progressId).hide();
                    } else {
                        ShowAlert("Error", "Failed to retrieve court details. Please try again later.");
                        $(progressId).hide();
                    }
                },
                error: function () {
                    console.error('Failed to fetch court details');
                    ShowAlert("Error", "Failed to retrieve court details. Please try again later.");
                    $(progressId).hide();
                }
            });
        } else {
            $(progressId).hide();
        }
    }

    SaveCourt() {
        if ($("#edit_hdCourtId").val() === "") {
            this.CreateCourt();
        } else {
            this.UpdateCourt();
        }
        if (courtControllerInstance.courtTable) {
            courtControllerInstance.ClearEditForm();
            courtControllerInstance.courtTable.draw();
        }
        window.location.href = '/court';
    }

    CreateCourt() {
        try {
            $("#edit_progress-court").show();
            const courtData = {
                description: $("#edit_courtDescription").val(),
                case_num_format: $("#edit_courtCaseNumFormat").val(),
                county_id: $("#edit_courtCounty").val() || 0,
                plaintiff: $("#edit_courtPlaintiff").val(),
                defendant: $("#edit_courtDefendant").val(),
                def_attorney_id: $("#edit_defAttorney").val() || null,
                opp_attorney_id: $("#edit_oppAttorney").val() || null,
                email_confirmations: $("#edit_emailConfirmations").val() === "1",
                calendar_weeks: parseInt($("#edit_calendarWeeks").val()) || 0,
                auto_extension: $("#edit_autoExtensionAuto").is(":checked"),
                custom_email_body: $("#edit_customEmailBody").val(),
                timeslot_header: $("#edit_timeslotHeader").val(),
                custom_header: $("#edit_customHeader").val()
            };
            $.ajax({
                url: `${this.service.baseUrl}CourtAPI/CreateCourt`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(courtData),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-court").hide();
                        ShowAlert("Success", "Court created successfully.");
                    } else {
                        $("#edit_progress-court").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-court").hide();
                    ShowAlert("Error Creating Court", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-court").hide();
            ShowAlert("Error Creating Court", e.statusText);
        }
    }

    UpdateCourt() {
        try {
            $("#edit_progress-court").show();
            const courtData = {
                id: $("#edit_hdCourtId").val(),
                description: $("#edit_courtDescription").val(),
                case_num_format: $("#edit_courtCaseNumFormat").val(),
                county_id: $("#edit_courtCounty").val() || 0,
                plaintiff: $("#edit_courtPlaintiff").val(),
                defendant: $("#edit_courtDefendant").val(),
                def_attorney_id: $("#edit_defAttorney").val() || null,
                opp_attorney_id: $("#edit_oppAttorney").val() || null,
                email_confirmations: $("#edit_emailConfirmations").val() === "1",
                calendar_weeks: parseInt($("#edit_calendarWeeks").val()) || 0,
                auto_extension: $("#edit_autoExtensionAuto").is(":checked"),
                custom_email_body: $("#edit_customEmailBody").val(),
                timeslot_header: $("#edit_timeslotHeader").val(),
                custom_header: $("#edit_customHeader").val()
            };
            $.ajax({
                url: `${this.service.baseUrl}CourtAPI/UpdateCourt`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(courtData),
                beforeSend: function (xhr) {
                    xhr.setRequestHeader('ModuleId', moduleId);
                    xhr.setRequestHeader('TabId', service.framework.getTabId());
                    xhr.setRequestHeader('RequestVerificationToken', service.framework.getAntiForgeryValue());
                },
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-court").hide();
                        ShowAlert("Success", "Court updated successfully.");
                    } else {
                        $("#edit_progress-court").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-court").hide();
                    ShowAlert("Error Updating Court", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-court").hide();
            ShowAlert("Error Updating Court", e.statusText);
        }
    }
}