﻿let courtMotionControllerInstance = null;

class CourtMotionController {
    constructor(params = {}) {
        this.moduleId = params.moduleId || -1;
        this.userId = params.userId || -1;
        this.isAdmin = params.isAdmin || false;
        this.adminRole = params.adminRole || 'Admin';
        this.pageSize = params.pageSize || 25;
        this.sortDirection = params.sortDirection || 'asc';
        this.recordCount = params.recordCount || 0;
        this.sortColumnIndex = params.sortColumnIndex || 2;
        this.currentPage = params.currentPage || 0;
        this.courtMotionId = -1;
        this.searchTerm = "";
        this.courtMotionTable = null;
        this.service = params.service || null;
        this.deleteUrl = null;
        courtMotionControllerInstance = this;
    }

    init() {
        const isAdmin = this.isAdmin;
        this.service.baseUrl = this.service.framework.getServiceRoot(this.service.path);
        this.deleteUrl = `${this.service.baseUrl}CourtMotionAPI/DeleteCourtMotion/`;

        const listUrl = `${this.service.baseUrl}CourtMotionAPI/GetCourtMotions/${this.recordCount}`;
        const detailModalElement = document.getElementById('CourtMotionDetailModal');
        if (detailModalElement) {
            detailModalElement.addEventListener('hidden.bs.modal', this.onModalClose);
        }

        const editModalElement = document.getElementById('CourtMotionEditModal');
        if (editModalElement) {
            editModalElement.addEventListener('hidden.bs.modal', this.onModalClose);
        }
        $(editModalElement).on('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey && !e.altKey) {
                e.preventDefault();
                $("#edit_cmdSave").trigger('click');
            }
        });
        this.courtMotionTable = $('#tblCourtMotion').DataTable({
            searching: true,
            autoWidth: true,
            stateSave: true,
            ajax: {
                url: listUrl,
                type: "GET",
                datatype: 'json',
                data(data) {
                    data.searchText = data.search.value;
                    delete data.columns;
                },
                error: function (error) {
                    $("#tblCourtMotion_processing").hide();
                    if (error.status === 401) {
                        ShowAlert("Error Retrieving Motions", "Please make sure you are logged in and try again. Error: " + error.statusText);
                    } else {
                        ShowAlert("Error Retrieving Motions", "The following error occurred attempting to retrieve motion information. Error: " + error.statusText);
                    }
                }
            },
            columns: [
                {
                    data: "id",
                    render: function (data) {
                        return `<button type="button" title="View Details" data-toggle="tooltip" data-id="${data}" class="cm-detail btn-command"><i class="fas fa-eye"></i></button>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "id",
                    render: function (data) {
                        return `<button type="button" title="Edit Court Motion" data-toggle="tooltip" data-id="${data}" class="cm-edit btn-command"><i class="fas fa-pencil"></i></button>`;
                    },
                    className: "command-item",
                    orderable: false
                },
                {
                    data: "court_id",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "motion_id",
                    render: function (data) {
                        return data || '';
                    }
                },
                {
                    data: "allowed",
                    render: function (data) {
                        return data ? 'Yes' : 'No';
                    }
                },
                {
                    data: "id",
                    render: function (data, type, row) {
                        if (isAdmin === "True") {
                            return `<button type="button" class="delete btn-command" data-toggle="tooltip" aria-role="button" title="Delete Court Motion" data-id="${row.id}"><i class="fas fa-trash"></i></button>`;
                        }
                        return '';
                    },
                    className: "command-item",
                    orderable: false
                },
            ],
            language: {
                emptyTable: "No Records Available.",
                zeroRecords: "No records match the search criteria you entered."
            },
            order: [[this.sortColumnIndex, this.sortDirection]],
            serverSide: true,
            processing: true,
            lengthMenu: [[25, 50, 100], [25, 50, 100]],
            pageLength: this.pageSize,
            displayStart: this.currentPage * this.pageSize,
        });

        $("#tblCourtMotion_length").prepend($("#lnkAdd"));
        this.courtMotionTable.on('draw', function () {
            
            $(".delete").on("click", function (e) {
                e.preventDefault();
                const courtMotionId = $(this).data("id");
                $.dnnConfirm({
                    text: 'Are you sure you wish to delete this Court Motion?',
                    yesText: 'Yes',
                    noText: 'No',
                    title: 'Delete Court Motion?',
                    callbackTrue: function () {
                        courtMotionControllerInstance.DeleteCourtMotion(courtMotionId);
                    }
                });
            });
        });

        $(document).on('click', '.cm-detail', function (e) {
            e.preventDefault();
            var courtMotionId = $(this).data("id");
            courtMotionControllerInstance.ViewCourtMotion(courtMotionId, false);
        });

        const editModal = new bootstrap.Modal(document.getElementById('CourtMotionEditModal'));
        $(document).on('click', '.cm-edit, #editCourtMotionBtn', function (e) {
            e.preventDefault();
            var courtMotionId = $(this).data("id") || $("#hdCourtMotionId").val();
            courtMotionControllerInstance.courtMotionId = courtMotionId;
            if (courtMotionId) {
                courtMotionControllerInstance.ViewCourtMotion(courtMotionId, true);
                $("#CourtMotionEditModalLabel").html(`Edit Court Motion`);
            } else {
                courtMotionControllerInstance.ClearEditForm();
                $("#CourtMotionEditModalLabel").html("Create New Court Motion");
            }
            editModal.show();
        });

        $("#lnkAdd").on('click', function (e) {
            e.preventDefault();
            courtMotionControllerInstance.ClearEditForm();
            $("#CourtMotionEditModalLabel").html("Create New Court Motion");
            editModal.show();
        });

        $("#cmdDelete").on("click", function (e) {
            e.preventDefault();
            var courtMotionId = $("#hdCourtMotionId").val();
            $.dnnConfirm({
                text: 'Are you sure you wish to delete this Court Motion?',
                yesText: 'Yes',
                noText: 'No',
                title: 'Delete Court Motion?',
                callbackTrue: function () {
                    courtMotionControllerInstance.DeleteCourtMotion(courtMotionId);
                }
            });
        });

        $("#edit_cmdSave").on("click", function (e) {
            e.preventDefault();
            let isValid = true;

            const $courtId = $("#edit_courtId");
            const $courtIdError = $courtId.next(".invalid-feedback");
            if ($courtId.val().trim() === "") {
                $courtIdError.show();
                $courtId.addClass("is-invalid");
                isValid = false;
            } else {
                $courtIdError.hide();
                $courtId.removeClass("is-invalid");
            }

            const $motionId = $("#edit_motionId");
            const $motionIdError = $motionId.next(".invalid-feedback");
            if ($motionId.val().trim() === "") {
                $motionIdError.show();
                $motionId.addClass("is-invalid");
                isValid = false;
            } else {
                $motionIdError.hide();
                $motionId.removeClass("is-invalid");
            }

            if (isValid) {
                courtMotionControllerInstance.SaveCourtMotion();
            }
        });

        $("#edit_courtId, #edit_motionId").on("input", function () {
            const $this = $(this);
            if ($this.val().trim() !== "") {
                $this.next(".invalid-feedback").hide();
                $this.removeClass("is-invalid");
            }
        });
    }

    ClearState() {
        if (this.courtMotionTable) {
            this.courtMotionTable.state.clear();
            window.location.reload();
        }
    }

    DeleteCourtMotion(courtMotionId) {
        $.ajax({
            url: this.deleteUrl + courtMotionId,
            type: 'GET',
            success: function (result) {
                if (courtMotionControllerInstance.courtMotionTable) {
                    courtMotionControllerInstance.courtMotionTable.draw();
                }
                const editModal = bootstrap.Modal.getInstance(document.getElementById('CourtMotionEditModal'));
                if (editModal) {
                    editModal.hide();
                }
                const detailModal = bootstrap.Modal.getInstance(document.getElementById('CourtMotionDetailModal'));
                if (detailModal) {
                    detailModal.hide();
                }
            },
            error: function (error) {
                ShowAlert("Error Deleting Court Motion", error.statusText);
            }
        });
    }

    onModalClose(event) {
        const modalId = event.target.id;
        if (modalId === 'CourtMotionDetailModal') {
            courtMotionControllerInstance.ClearDetailForm();
        } else if (modalId === 'CourtMotionEditModal') {
            courtMotionControllerInstance.ClearEditForm();
            courtMotionControllerInstance.ClearEditValidations();
        }
    }

    ClearDetailForm() {
        $("#courtId").html("");
        $("#motionId").html("");
        $("#allowed").html("");
        $("#hdCourtMotionId").val("");
    }

    ClearEditForm() {
        $("#edit_courtId").val("");
        $("#edit_motionId").val("");
        $("#edit_allowed").prop("checked", false);
        $("#edit_hdCourtMotionId").val("");
    }

    ClearEditValidations() {
        $("#edit_courtId, #edit_motionId").removeClass("is-invalid");
        $("#edit_courtId, #edit_motionId").next(".invalid-feedback").hide();
    }

    ViewCourtMotion(courtMotionId, isEditMode = false) {
        const getUrl = `${this.service.baseUrl}CourtMotionAPI/GetCourtMotion/${courtMotionId}`;
        const progressId = isEditMode ? "#edit_progress-courtmotion" : "#progress-courtmotion";
        $(progressId).show();

        if (!isEditMode) {
            const modal = new bootstrap.Modal(document.getElementById('CourtMotionDetailModal'));
            if (!modal._element.classList.contains('show')) {
                modal.show();
            }
        }

        if (courtMotionId) {
            $.ajax({
                url: getUrl,
                method: 'GET',
                dataType: 'json',
                success: function (response) {
                    if (response.data) {
                        if (isEditMode) {
                            $("#edit_hdCourtMotionId").val(response.data.id);
                            $("#edit_courtId").val(response.data.court_id);
                            $("#edit_motionId").val(response.data.motion_id);
                            $("#edit_allowed").prop("checked", response.data.allowed);
                            $("#CourtMotionEditModalLabel").html(`Edit Court Motion`);
                        } else {
                            $("#courtId").html(response.data.court_id);
                            $("#motionId").html(response.data.motion_id);
                            $("#allowed").html(response.data.allowed ? 'Yes' : 'No');
                            $("#hdCourtMotionId").val(response.data.id);
                        }
                        $(progressId).hide();
                    } else {
                        ShowAlert("Error", "Failed to retrieve court motion details. Please try again later.");
                        $(progressId).hide();
                    }
                },
                error: function () {
                    console.error('Failed to fetch court motion details');
                    ShowAlert("Error", "Failed to retrieve court motion details. Please try again later.");
                    $(progressId).hide();
                }
            });
        } else {
            $(progressId).hide();
        }
    }

    SaveCourtMotion() {
        if ($("#edit_hdCourtMotionId").val() === "") {
            this.CreateCourtMotion();
        } else {
            this.UpdateCourtMotion();
        }
        if (courtMotionControllerInstance.courtMotionTable) {
            courtMotionControllerInstance.ClearEditForm();
            courtMotionControllerInstance.courtMotionTable.draw();
        }
    }

    CreateCourtMotion() {
        try {
            $("#edit_progress-courtmotion").show();
            const courtMotionData = {
                court_id: $("#edit_courtId").val(),
                motion_id: $("#edit_motionId").val(),
                allowed: $("#edit_allowed").is(":checked")
            };
            $.ajax({
                url: `${this.service.baseUrl}CourtMotionAPI/CreateCourtMotion`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(courtMotionData),
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-courtmotion").hide();
                        ShowAlert("Success", "Court Motion created successfully.");
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('CourtMotionEditModal'));
                        if (editModal) {
                            editModal.hide();
                        }
                    } else {
                        $("#edit_progress-courtmotion").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-courtmotion").hide();
                    ShowAlert("Error Creating Court Motion", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-courtmotion").hide();
            ShowAlert("Error Creating Court Motion", e.statusText);
        }
    }

    UpdateCourtMotion() {
        try {
            $("#edit_progress-courtmotion").show();
            const courtMotionData = {
                id: $("#edit_hdCourtMotionId").val(),
                court_id: $("#edit_courtId").val(),
                motion_id: $("#edit_motionId").val(),
                allowed: $("#edit_allowed").is(":checked")
            };
            $.ajax({
                url: `${this.service.baseUrl}CourtMotionAPI/UpdateCourtMotion`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(courtMotionData),
                success: function (result) {
                    if (result === 200) {
                        $("#edit_progress-courtmotion").hide();
                        ShowAlert("Success", "Court Motion updated successfully.");
                        const editModal = bootstrap.Modal.getInstance(document.getElementById('CourtMotionEditModal'));
                        if (editModal) {
                            editModal.hide();
                        }
                    } else {
                        $("#edit_progress-courtmotion").hide();
                        ShowAlert("Error", "Unexpected Error: Status=" + result);
                    }
                },
                error: function (error) {
                    $("#edit_progress-courtmotion").hide();
                    ShowAlert("Error Updating Court Motion", error.statusText);
                }
            });
        } catch (e) {
            $("#edit_progress-courtmotion").hide();
            ShowAlert("Error Updating Court Motion", e.statusText);
        }
    }
}